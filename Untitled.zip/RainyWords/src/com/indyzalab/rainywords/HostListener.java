package com.indyzalab.rainywords;

public interface HostListener{
	public void startHosting();
}