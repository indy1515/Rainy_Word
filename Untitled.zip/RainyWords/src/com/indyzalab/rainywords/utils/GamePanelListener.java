package com.indyzalab.rainywords.utils;

public interface GamePanelListener {
	public void onTick(int current_time);
	public void onTimerComplete();
}
